# INFO7374
Group 6 members:
Byron Kiriibwa, 
Xuewen Xu, 
Yuchen Qiao
